suhuF = int(input("suhu dalam skala Fahrenheit :"))

FkeC = int((5/9)*(suhuF-32))
print (suhuF,"derajat Farenheit dikonversi menjadi", FkeC, "derajat Celcius")
           
