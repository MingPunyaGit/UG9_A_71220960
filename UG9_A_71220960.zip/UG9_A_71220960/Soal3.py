import math
p = int(input("masukan panjang :"))
l = int(input("masukan lebar :"))
t = int(input("masukan jari :"))
luaslingkaran = float (((math.pi)*(r**2))/2)
luaspp = float (p*1)
umlahkaleng = float(((luaslingkaran+luaspp)/15))
print ("Area tersebut membutuhkan",math.cel(jumlahkaleng),"kaleng cat")

