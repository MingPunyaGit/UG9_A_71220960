Python 3.11.0 (main, Oct 24 2022, 18:26:48) [MSC v.1933 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
======== RESTART: C:/Users/MSI GF63/OneDrive/Documents/UG9_A_71220960.py =======
Nama Anda: Ming Fee
Nama Mata Kuliah: Pratikum Teknologi Komputer
Masukan Grup Amda: A
hallo Ming Fee
anda tergabung dalam Pratikum Teknologi Komputer pada grup A
>>> 
======== RESTART: C:/Users/MSI GF63/OneDrive/Documents/UG9_A_71220960.py =======
Nama Anda: Ming Fee
Nama Mata kuliah: Logika Matematika 
Masukan Grup Anda: A
Haloo+ namaMahasiswa
Anda tergabung dalam Logika Matematika  pada grup A
