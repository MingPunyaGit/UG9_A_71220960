Python 3.11.0 (main, Oct 24 2022, 18:26:48) [MSC v.1933 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
============ RESTART: C:/Users/MSI GF63/OneDrive/Documents/Soal2.py ============
suhu dalam skala Fahrenheit :58
58 derajat Farenheit dikonversi menjadi 14 derajat Celcius
>>> 
============ RESTART: C:/Users/MSI GF63/OneDrive/Documents/Soal2.py ============
suhu dalam skala Fahrenheit :84
84 derajat Farenheit dikonversi menjadi 28 derajat Celcius
